<?php
print("<pre>".print_r($_POST,true)."</pre>");
 ?>
<br>
<a href="form.html">Retour au formulaire</a>
